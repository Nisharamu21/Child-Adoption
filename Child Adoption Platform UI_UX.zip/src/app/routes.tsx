import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { Welcome } from "./components/onboarding/Welcome";
import { OnboardingSteps } from "./components/onboarding/OnboardingSteps";
import { Dashboard } from "./components/Dashboard";
import { ProfileSetup } from "./components/ProfileSetup";
import { Search } from "./components/Search";
import { Applications } from "./components/Applications";
import { Resources } from "./components/Resources";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <Welcome />,
  },
  {
    path: "/onboarding",
    element: <OnboardingSteps />,
  },
  {
    path: "/",
    element: <Layout />,
    children: [
      {
        path: "dashboard",
        element: <Dashboard />,
      },
      {
        path: "profile",
        element: <ProfileSetup />,
      },
      {
        path: "search",
        element: <Search />,
      },
      {
        path: "applications",
        element: <Applications />,
      },
      {
        path: "resources",
        element: <Resources />,
      },
    ],
  },
]);
