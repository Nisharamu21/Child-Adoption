import { useState } from "react";
import { Filter, Heart, Users, Calendar } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface Child {
  id: number;
  name: string;
  age: number;
  gender: string;
  image: string;
  location: string;
  interests: string[];
  bio: string;
  specialNeeds: boolean;
  siblings?: number;
}

const mockChildren: Child[] = [
  {
    id: 1,
    name: "Emma",
    age: 7,
    gender: "Female",
    image: "https://images.unsplash.com/photo-1567516364473-233c4b6fcfbe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMGdpcmwlMjBzbWlsaW5nfGVufDF8fHx8MTc3MDI3NzEwMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    location: "California",
    interests: ["Drawing", "Dancing", "Reading"],
    bio: "Emma loves to express herself through art and enjoys spending time outdoors. She's looking for a loving family who will support her creative spirit.",
    specialNeeds: false,
  },
  {
    id: 2,
    name: "Marcus",
    age: 10,
    gender: "Male",
    image: "https://images.unsplash.com/photo-1669787210553-44e4f95106ad?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMGJveSUyMHBvcnRyYWl0fGVufDF8fHx8MTc3MDI3NzA5OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    location: "Texas",
    interests: ["Soccer", "Science", "Video Games"],
    bio: "Marcus is an energetic and curious boy who loves learning new things. He dreams of becoming a scientist and would thrive with an encouraging family.",
    specialNeeds: false,
  },
  {
    id: 3,
    name: "Sofia",
    age: 14,
    gender: "Female",
    image: "https://images.unsplash.com/photo-1520423465871-0866049020b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWVuYWdlciUyMHBvcnRyYWl0fGVufDF8fHx8MTc3MDI3NzEwMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    location: "New York",
    interests: ["Music", "Writing", "Photography"],
    bio: "Sofia is a thoughtful teenager with a passion for the arts. She's looking for a family that values communication and will support her aspirations.",
    specialNeeds: false,
  },
  {
    id: 4,
    name: "Lily & Jake",
    age: 8,
    gender: "Siblings",
    image: "https://images.unsplash.com/photo-1767082089854-e673b4b75774?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzaWJsaW5ncyUyMGNoaWxkcmVuJTIwdG9nZXRoZXJ8ZW58MXx8fHwxNzcwMjc3MTAwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    location: "Florida",
    interests: ["Swimming", "Cooking", "Animals"],
    bio: "Lily (8) and Jake (6) are inseparable siblings looking for a family to adopt them together. They love outdoor activities and have wonderful imaginations.",
    specialNeeds: false,
    siblings: 2,
  },
];

export function Search() {
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    ageMin: "",
    ageMax: "",
    gender: "",
    location: "",
    specialNeeds: false,
    siblingsOnly: false,
  });
  const [savedChildren, setSavedChildren] = useState<number[]>([]);

  const toggleSave = (childId: number) => {
    setSavedChildren((prev) =>
      prev.includes(childId)
        ? prev.filter((id) => id !== childId)
        : [...prev, childId]
    );
  };

  const filteredChildren = mockChildren.filter((child) => {
    if (filters.ageMin && child.age < parseInt(filters.ageMin)) return false;
    if (filters.ageMax && child.age > parseInt(filters.ageMax)) return false;
    if (filters.gender && filters.gender !== "all" && child.gender !== filters.gender && child.gender !== "Siblings") return false;
    if (filters.siblingsOnly && !child.siblings) return false;
    return true;
  });

  return (
    <div className="container mx-auto px-4 py-8 pb-24 md:pb-8">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">Find Your Match</h1>
        <p className="text-gray-600">
          Browse children who are waiting for a loving family
        </p>
      </div>

      {/* Filter Toggle */}
      <div className="mb-6">
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="flex items-center gap-2 px-4 py-2 bg-white rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors"
        >
          <Filter className="size-5" />
          <span>{showFilters ? "Hide" : "Show"} Filters</span>
        </button>
      </div>

      {/* Filters */}
      {showFilters && (
        <div className="bg-white rounded-2xl p-6 shadow-sm mb-8">
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <label className="block text-sm mb-2 text-gray-700">Age Range (Min)</label>
              <select
                value={filters.ageMin}
                onChange={(e) => setFilters({ ...filters, ageMin: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
              >
                <option value="">Any</option>
                {[0, 2, 4, 6, 8, 10, 12, 14, 16].map((age) => (
                  <option key={age} value={age}>
                    {age} years
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm mb-2 text-gray-700">Age Range (Max)</label>
              <select
                value={filters.ageMax}
                onChange={(e) => setFilters({ ...filters, ageMax: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
              >
                <option value="">Any</option>
                {[2, 4, 6, 8, 10, 12, 14, 16, 18].map((age) => (
                  <option key={age} value={age}>
                    {age} years
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm mb-2 text-gray-700">Gender</label>
              <select
                value={filters.gender}
                onChange={(e) => setFilters({ ...filters, gender: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
              >
                <option value="">Any</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>
            </div>
          </div>
          <div className="flex gap-6 mt-4">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.siblingsOnly}
                onChange={(e) => setFilters({ ...filters, siblingsOnly: e.target.checked })}
                className="size-4 text-orange-500 rounded focus:ring-2 focus:ring-orange-500"
              />
              <span className="text-gray-700">Sibling Groups Only</span>
            </label>
          </div>
        </div>
      )}

      {/* Results Count */}
      <div className="mb-6">
        <p className="text-gray-600">
          {filteredChildren.length} {filteredChildren.length === 1 ? "child" : "children"} found
        </p>
      </div>

      {/* Children Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredChildren.map((child) => (
          <div
            key={child.id}
            className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-shadow"
          >
            <div className="relative h-64">
              <ImageWithFallback
                src={child.image}
                alt={child.name}
                className="w-full h-full object-cover"
              />
              <button
                onClick={() => toggleSave(child.id)}
                className={`absolute top-4 right-4 size-10 rounded-full flex items-center justify-center transition-colors ${
                  savedChildren.includes(child.id)
                    ? "bg-orange-500 text-white"
                    : "bg-white/90 text-gray-600 hover:bg-orange-100"
                }`}
              >
                <Heart
                  className={`size-5 ${
                    savedChildren.includes(child.id) ? "fill-white" : ""
                  }`}
                />
              </button>
            </div>
            <div className="p-6">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="text-xl mb-1">{child.name}</h3>
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <span className="flex items-center gap-1">
                      <Calendar className="size-4" />
                      {child.age} years
                    </span>
                    {child.siblings && (
                      <span className="flex items-center gap-1">
                        <Users className="size-4" />
                        {child.siblings} siblings
                      </span>
                    )}
                  </div>
                </div>
              </div>
              <p className="text-gray-600 mb-4 line-clamp-3">{child.bio}</p>
              <div className="flex flex-wrap gap-2 mb-4">
                {child.interests.slice(0, 3).map((interest, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1 bg-orange-50 text-orange-700 rounded-full text-sm"
                  >
                    {interest}
                  </span>
                ))}
              </div>
              <button className="w-full py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors">
                Learn More
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredChildren.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-600 text-lg">
            No children match your current filters. Try adjusting your search criteria.
          </p>
        </div>
      )}
    </div>
  );
}
