import { useState } from "react";
import { useNavigate } from "react-router";
import { Save, CheckCircle2 } from "lucide-react";

export function ProfileSetup() {
  const navigate = useNavigate();
  const [saved, setSaved] = useState(false);
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    zip: "",
    maritalStatus: "",
    occupation: "",
    householdIncome: "",
    hasChildren: "",
    hasPets: "",
    agePreferenceMin: "",
    agePreferenceMax: "",
    specialNeeds: false,
    siblingGroups: false,
    adoptionType: "",
    motivation: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (type === "checkbox") {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData({ ...formData, [name]: checked });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSaved(true);
    setTimeout(() => {
      navigate("/dashboard");
    }, 2000);
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl pb-24 md:pb-8">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">Create Your Profile</h1>
        <p className="text-gray-600">
          Help us understand you better so we can support your adoption journey
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Personal Information */}
        <div className="bg-white rounded-2xl p-8 shadow-sm">
          <h2 className="text-2xl mb-6 text-gray-900">Personal Information</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm mb-2 text-gray-700">First Name *</label>
              <input
                type="text"
                name="firstName"
                value={formData.firstName}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
              />
            </div>
            <div>
              <label className="block text-sm mb-2 text-gray-700">Last Name *</label>
              <input
                type="text"
                name="lastName"
                value={formData.lastName}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
              />
            </div>
            <div>
              <label className="block text-sm mb-2 text-gray-700">Email *</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
              />
            </div>
            <div>
              <label className="block text-sm mb-2 text-gray-700">Phone *</label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm mb-2 text-gray-700">Address *</label>
              <input
                type="text"
                name="address"
                value={formData.address}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
              />
            </div>
            <div>
              <label className="block text-sm mb-2 text-gray-700">City *</label>
              <input
                type="text"
                name="city"
                value={formData.city}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
              />
            </div>
            <div>
              <label className="block text-sm mb-2 text-gray-700">State *</label>
              <input
                type="text"
                name="state"
                value={formData.state}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
              />
            </div>
          </div>
        </div>

        {/* Household Information */}
        <div className="bg-white rounded-2xl p-8 shadow-sm">
          <h2 className="text-2xl mb-6 text-gray-900">Household Information</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm mb-2 text-gray-700">Marital Status *</label>
              <select
                name="maritalStatus"
                value={formData.maritalStatus}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
              >
                <option value="">Select...</option>
                <option value="single">Single</option>
                <option value="married">Married</option>
                <option value="partnered">Partnered</option>
                <option value="divorced">Divorced</option>
              </select>
            </div>
            <div>
              <label className="block text-sm mb-2 text-gray-700">Occupation *</label>
              <input
                type="text"
                name="occupation"
                value={formData.occupation}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
              />
            </div>
            <div>
              <label className="block text-sm mb-2 text-gray-700">Household Income Range *</label>
              <select
                name="householdIncome"
                value={formData.householdIncome}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
              >
                <option value="">Select...</option>
                <option value="under50k">Under $50,000</option>
                <option value="50k-100k">$50,000 - $100,000</option>
                <option value="100k-150k">$100,000 - $150,000</option>
                <option value="over150k">Over $150,000</option>
              </select>
            </div>
            <div>
              <label className="block text-sm mb-2 text-gray-700">Do you have children? *</label>
              <select
                name="hasChildren"
                value={formData.hasChildren}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
              >
                <option value="">Select...</option>
                <option value="yes">Yes</option>
                <option value="no">No</option>
              </select>
            </div>
          </div>
        </div>

        {/* Adoption Preferences */}
        <div className="bg-white rounded-2xl p-8 shadow-sm">
          <h2 className="text-2xl mb-6 text-gray-900">Adoption Preferences</h2>
          <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm mb-2 text-gray-700">Preferred Age Range (Min) *</label>
                <select
                  name="agePreferenceMin"
                  value={formData.agePreferenceMin}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
                >
                  <option value="">Select...</option>
                  {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17].map(age => (
                    <option key={age} value={age}>{age} years</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm mb-2 text-gray-700">Preferred Age Range (Max) *</label>
                <select
                  name="agePreferenceMax"
                  value={formData.agePreferenceMax}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
                >
                  <option value="">Select...</option>
                  {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17].map(age => (
                    <option key={age} value={age}>{age} years</option>
                  ))}
                </select>
              </div>
            </div>
            <div>
              <label className="block text-sm mb-2 text-gray-700">Adoption Type *</label>
              <select
                name="adoptionType"
                value={formData.adoptionType}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
              >
                <option value="">Select...</option>
                <option value="open">Open Adoption</option>
                <option value="semi-open">Semi-Open Adoption</option>
                <option value="closed">Closed Adoption</option>
              </select>
            </div>
            <div className="space-y-3">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  name="specialNeeds"
                  checked={formData.specialNeeds}
                  onChange={handleChange}
                  className="size-5 text-orange-500 rounded focus:ring-2 focus:ring-orange-500"
                />
                <span className="text-gray-700">Open to children with special needs</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  name="siblingGroups"
                  checked={formData.siblingGroups}
                  onChange={handleChange}
                  className="size-5 text-orange-500 rounded focus:ring-2 focus:ring-orange-500"
                />
                <span className="text-gray-700">Open to sibling groups</span>
              </label>
            </div>
            <div>
              <label className="block text-sm mb-2 text-gray-700">What motivates you to adopt? *</label>
              <textarea
                name="motivation"
                value={formData.motivation}
                onChange={handleChange}
                required
                rows={4}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none resize-none"
                placeholder="Tell us about your journey and why you want to adopt..."
              />
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <div className="flex justify-end gap-4">
          <button
            type="button"
            onClick={() => navigate("/dashboard")}
            className="px-8 py-3 text-gray-600 hover:text-gray-900 transition-colors"
          >
            Skip for Now
          </button>
          <button
            type="submit"
            disabled={saved}
            className="flex items-center gap-2 px-8 py-3 bg-orange-500 text-white rounded-full hover:bg-orange-600 transition-colors shadow-lg disabled:bg-green-500"
          >
            {saved ? (
              <>
                <CheckCircle2 className="size-5" />
                Saved!
              </>
            ) : (
              <>
                <Save className="size-5" />
                Save Profile
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
