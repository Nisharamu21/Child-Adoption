import { useState } from "react";
import { BookOpen, Video, FileText, Download, Search, Heart, Home, Users, Clock } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface Resource {
  id: number;
  title: string;
  description: string;
  type: "guide" | "video" | "article" | "checklist";
  category: "getting-started" | "preparation" | "legal" | "post-adoption";
  duration?: string;
  image?: string;
  completed?: boolean;
}

const mockResources: Resource[] = [
  {
    id: 1,
    title: "Getting Started with Adoption",
    description: "A comprehensive guide for prospective parents beginning their adoption journey",
    type: "guide",
    category: "getting-started",
    duration: "15 min read",
    image: "https://images.unsplash.com/photo-1760840414854-36cd365d14f1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZWFkaW5nJTIwYm9vayUyMGxlYXJuaW5nfGVufDF8fHx8MTc3MDI3NzIyNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    completed: true,
  },
  {
    id: 2,
    title: "Preparing Your Home for a Child",
    description: "Essential tips and a room-by-room checklist for creating a safe, welcoming environment",
    type: "checklist",
    category: "preparation",
    duration: "10 min read",
    image: "https://images.unsplash.com/photo-1605191353027-d21e534a419a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob21lJTIwaW50ZXJpb3IlMjBjb3p5fGVufDF8fHx8MTc3MDI3NzIyNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    completed: true,
  },
  {
    id: 3,
    title: "Understanding the Home Study Process",
    description: "What to expect during your home study and how to prepare",
    type: "video",
    category: "legal",
    duration: "22 min",
    image: "https://images.unsplash.com/photo-1654613698246-b6d44aef0fd5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW1pbHklMjBjb3Vuc2VsaW5nJTIwc3VwcG9ydHxlbnwxfHx8fDE3NzAyNzcyMjR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 4,
    title: "Building Attachment with Your Adopted Child",
    description: "Expert advice on creating strong bonds and addressing attachment challenges",
    type: "article",
    category: "post-adoption",
    duration: "12 min read",
  },
  {
    id: 5,
    title: "Legal Rights and Responsibilities",
    description: "Understanding your legal obligations and rights as an adoptive parent",
    type: "guide",
    category: "legal",
    duration: "20 min read",
  },
  {
    id: 6,
    title: "Financial Planning for Adoption",
    description: "Budgeting, tax credits, and financial assistance programs",
    type: "guide",
    category: "getting-started",
    duration: "18 min read",
  },
];

const categories = [
  { key: "all", label: "All Resources", icon: BookOpen },
  { key: "getting-started", label: "Getting Started", icon: Heart },
  { key: "preparation", label: "Preparation", icon: Home },
  { key: "legal", label: "Legal & Process", icon: FileText },
  { key: "post-adoption", label: "Post-Adoption", icon: Users },
];

const typeIcons = {
  guide: BookOpen,
  video: Video,
  article: FileText,
  checklist: FileText,
};

export function Resources() {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredResources = mockResources.filter((resource) => {
    const matchesCategory =
      selectedCategory === "all" || resource.category === selectedCategory;
    const matchesSearch =
      searchQuery === "" ||
      resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      resource.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="container mx-auto px-4 py-8 pb-24 md:pb-8">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">Resources & Support</h1>
        <p className="text-gray-600">
          Guides, articles, and tools to support you throughout your adoption journey
        </p>
      </div>

      {/* Search */}
      <div className="mb-8">
        <div className="relative max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 size-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search resources..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
          />
        </div>
      </div>

      {/* Categories */}
      <div className="flex gap-3 mb-8 overflow-x-auto pb-2">
        {categories.map((category) => {
          const Icon = category.icon;
          return (
            <button
              key={category.key}
              onClick={() => setSelectedCategory(category.key)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
                selectedCategory === category.key
                  ? "bg-orange-500 text-white"
                  : "bg-white text-gray-700 hover:bg-gray-50 border border-gray-200"
              }`}
            >
              <Icon className="size-4" />
              <span>{category.label}</span>
            </button>
          );
        })}
      </div>

      {/* Stats Banner */}
      <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-6 mb-8">
        <div className="grid md:grid-cols-3 gap-6">
          <div className="flex items-center gap-4">
            <div className="size-12 bg-blue-500 rounded-lg flex items-center justify-center">
              <BookOpen className="size-6 text-white" />
            </div>
            <div>
              <p className="text-2xl">24</p>
              <p className="text-sm text-gray-600">Total Resources</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="size-12 bg-green-500 rounded-lg flex items-center justify-center">
              <Clock className="size-6 text-white" />
            </div>
            <div>
              <p className="text-2xl">12</p>
              <p className="text-sm text-gray-600">Completed</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="size-12 bg-purple-500 rounded-lg flex items-center justify-center">
              <Heart className="size-6 text-white" />
            </div>
            <div>
              <p className="text-2xl">8</p>
              <p className="text-sm text-gray-600">Bookmarked</p>
            </div>
          </div>
        </div>
      </div>

      {/* Resources Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredResources.map((resource) => {
          const TypeIcon = typeIcons[resource.type];
          return (
            <div
              key={resource.id}
              className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-shadow"
            >
              {resource.image ? (
                <div className="relative h-48">
                  <ImageWithFallback
                    src={resource.image}
                    alt={resource.title}
                    className="w-full h-full object-cover"
                  />
                  {resource.completed && (
                    <div className="absolute top-4 right-4 px-3 py-1 bg-green-500 text-white rounded-full text-sm flex items-center gap-1">
                      <Download className="size-4" />
                      Completed
                    </div>
                  )}
                </div>
              ) : (
                <div className="h-48 bg-gradient-to-br from-orange-100 to-orange-200 flex items-center justify-center">
                  <TypeIcon className="size-16 text-orange-500" />
                </div>
              )}
              <div className="p-6">
                <div className="flex items-center gap-2 mb-3">
                  <TypeIcon className="size-4 text-gray-500" />
                  <span className="text-sm text-gray-500 capitalize">{resource.type}</span>
                  {resource.duration && (
                    <>
                      <span className="text-gray-300">•</span>
                      <span className="text-sm text-gray-500">{resource.duration}</span>
                    </>
                  )}
                </div>
                <h3 className="text-lg mb-2">{resource.title}</h3>
                <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                  {resource.description}
                </p>
                <button className="w-full py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors">
                  {resource.completed ? "Review" : resource.type === "video" ? "Watch" : "Read"}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {filteredResources.length === 0 && (
        <div className="text-center py-12">
          <BookOpen className="size-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-600 text-lg">
            No resources found matching your criteria.
          </p>
        </div>
      )}

      {/* Support Section */}
      <div className="mt-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl p-8 text-white">
        <h2 className="text-2xl mb-4">Need Personalized Support?</h2>
        <p className="mb-6 text-orange-50">
          Our experienced adoption counselors are here to help answer your questions and guide you through the process.
        </p>
        <div className="flex flex-wrap gap-4">
          <button className="px-6 py-3 bg-white text-orange-600 rounded-lg hover:bg-orange-50 transition-colors">
            Schedule a Call
          </button>
          <button className="px-6 py-3 bg-orange-700 text-white rounded-lg hover:bg-orange-800 transition-colors">
            Join Support Group
          </button>
        </div>
      </div>
    </div>
  );
}
