import { useState } from "react";
import { CheckCircle2, Clock, FileText, AlertCircle } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface Application {
  id: number;
  childName: string;
  childAge: number;
  childImage: string;
  status: "submitted" | "review" | "home-study" | "matching" | "placement";
  submittedDate: string;
  lastUpdate: string;
  nextSteps: string;
}

const mockApplications: Application[] = [
  {
    id: 1,
    childName: "Marcus",
    childAge: 10,
    childImage: "https://images.unsplash.com/photo-1669787210553-44e4f95106ad?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMGJveSUyMHBvcnRyYWl0fGVufDF8fHx8MTc3MDI3NzA5OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    status: "home-study",
    submittedDate: "Jan 15, 2026",
    lastUpdate: "Feb 3, 2026",
    nextSteps: "Complete home study visit scheduled for Feb 10, 2026",
  },
];

const statusConfig = {
  submitted: {
    label: "Application Submitted",
    color: "bg-blue-100 text-blue-800",
    icon: FileText,
  },
  review: {
    label: "Under Review",
    color: "bg-purple-100 text-purple-800",
    icon: Clock,
  },
  "home-study": {
    label: "Home Study",
    color: "bg-orange-100 text-orange-800",
    icon: Clock,
  },
  matching: {
    label: "Matching Process",
    color: "bg-indigo-100 text-indigo-800",
    icon: Clock,
  },
  placement: {
    label: "Placement",
    color: "bg-green-100 text-green-800",
    icon: CheckCircle2,
  },
};

const applicationStages = [
  { key: "submitted", label: "Application" },
  { key: "review", label: "Review" },
  { key: "home-study", label: "Home Study" },
  { key: "matching", label: "Matching" },
  { key: "placement", label: "Placement" },
];

export function Applications() {
  const [selectedTab, setSelectedTab] = useState<"active" | "archived">("active");

  const getStageIndex = (status: string) => {
    return applicationStages.findIndex((stage) => stage.key === status);
  };

  return (
    <div className="container mx-auto px-4 py-8 pb-24 md:pb-8">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">Application Tracking</h1>
        <p className="text-gray-600">
          Monitor the progress of your adoption applications
        </p>
      </div>

      {/* Tabs */}
      <div className="flex gap-4 mb-8 border-b border-gray-200">
        <button
          onClick={() => setSelectedTab("active")}
          className={`pb-4 px-2 transition-colors relative ${
            selectedTab === "active"
              ? "text-orange-600"
              : "text-gray-600 hover:text-gray-900"
          }`}
        >
          Active Applications
          {selectedTab === "active" && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-orange-600" />
          )}
        </button>
        <button
          onClick={() => setSelectedTab("archived")}
          className={`pb-4 px-2 transition-colors relative ${
            selectedTab === "archived"
              ? "text-orange-600"
              : "text-gray-600 hover:text-gray-900"
          }`}
        >
          Archived
          {selectedTab === "archived" && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-orange-600" />
          )}
        </button>
      </div>

      {/* Applications List */}
      {selectedTab === "active" && mockApplications.length > 0 && (
        <div className="space-y-6">
          {mockApplications.map((application) => {
            const statusInfo = statusConfig[application.status];
            const StatusIcon = statusInfo.icon;
            const currentStageIndex = getStageIndex(application.status);

            return (
              <div key={application.id} className="bg-white rounded-2xl shadow-sm overflow-hidden">
                {/* Header */}
                <div className="p-6 border-b border-gray-100">
                  <div className="flex items-start gap-4">
                    <div className="size-20 rounded-lg overflow-hidden flex-shrink-0">
                      <ImageWithFallback
                        src={application.childImage}
                        alt={application.childName}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="text-xl mb-1">
                            {application.childName}, {application.childAge}
                          </h3>
                          <p className="text-sm text-gray-600">
                            Submitted: {application.submittedDate}
                          </p>
                        </div>
                        <span className={`px-4 py-2 rounded-full text-sm flex items-center gap-2 ${statusInfo.color}`}>
                          <StatusIcon className="size-4" />
                          {statusInfo.label}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Progress Timeline */}
                <div className="p-6 bg-gray-50">
                  <h4 className="text-sm mb-4 text-gray-700">Application Progress</h4>
                  <div className="flex items-center justify-between">
                    {applicationStages.map((stage, index) => {
                      const isComplete = index < currentStageIndex;
                      const isCurrent = index === currentStageIndex;
                      const isPending = index > currentStageIndex;

                      return (
                        <div key={stage.key} className="flex items-center flex-1">
                          <div className="flex flex-col items-center flex-1">
                            <div
                              className={`size-10 rounded-full flex items-center justify-center mb-2 ${
                                isComplete
                                  ? "bg-green-500 text-white"
                                  : isCurrent
                                  ? "bg-orange-500 text-white"
                                  : "bg-gray-200 text-gray-400"
                              }`}
                            >
                              {isComplete ? (
                                <CheckCircle2 className="size-6" />
                              ) : isCurrent ? (
                                <Clock className="size-6" />
                              ) : (
                                <span className="text-sm">{index + 1}</span>
                              )}
                            </div>
                            <span className={`text-xs text-center ${isCurrent ? "font-medium" : ""}`}>
                              {stage.label}
                            </span>
                          </div>
                          {index < applicationStages.length - 1 && (
                            <div
                              className={`h-1 flex-1 -mt-8 ${
                                isComplete ? "bg-green-500" : "bg-gray-200"
                              }`}
                            />
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Next Steps */}
                <div className="p-6">
                  <div className="flex items-start gap-3 p-4 bg-blue-50 rounded-lg">
                    <AlertCircle className="size-5 text-blue-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="mb-1">Next Steps</h4>
                      <p className="text-sm text-gray-700">{application.nextSteps}</p>
                      <p className="text-xs text-gray-500 mt-2">
                        Last updated: {application.lastUpdate}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-3 mt-4">
                    <button className="flex-1 py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors">
                      View Details
                    </button>
                    <button className="flex-1 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                      Contact Counselor
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Empty States */}
      {selectedTab === "active" && mockApplications.length === 0 && (
        <div className="bg-white rounded-2xl p-12 text-center shadow-sm">
          <FileText className="size-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl mb-2">No Active Applications</h3>
          <p className="text-gray-600 mb-6">
            You haven't submitted any applications yet. Browse children profiles to get started.
          </p>
          <button className="px-6 py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors">
            Browse Children
          </button>
        </div>
      )}

      {selectedTab === "archived" && (
        <div className="bg-white rounded-2xl p-12 text-center shadow-sm">
          <FileText className="size-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl mb-2">No Archived Applications</h3>
          <p className="text-gray-600">
            Completed or withdrawn applications will appear here.
          </p>
        </div>
      )}

      {/* Information Panel */}
      <div className="mt-8 bg-gradient-to-br from-purple-50 to-blue-50 rounded-2xl p-6">
        <h3 className="text-lg mb-3">Understanding the Process</h3>
        <div className="grid md:grid-cols-2 gap-4 text-sm">
          <div>
            <h4 className="mb-2">Average Timeline</h4>
            <p className="text-gray-700">
              Most applications complete within 6-12 months, depending on individual circumstances.
            </p>
          </div>
          <div>
            <h4 className="mb-2">Need Help?</h4>
            <p className="text-gray-700">
              Contact your assigned counselor anytime with questions about your application.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
