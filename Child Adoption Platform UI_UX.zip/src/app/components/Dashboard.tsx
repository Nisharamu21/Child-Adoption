import { Link } from "react-router";
import { Heart, FileText, BookOpen, Clock, CheckCircle2, AlertCircle } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Dashboard() {
  const stats = [
    { label: "Saved Profiles", value: "3", icon: Heart, color: "text-orange-600", bg: "bg-orange-50" },
    { label: "Active Applications", value: "1", icon: FileText, color: "text-blue-600", bg: "bg-blue-50" },
    { label: "Resources Read", value: "12", icon: BookOpen, color: "text-green-600", bg: "bg-green-50" },
  ];

  const recentActivity = [
    {
      id: 1,
      type: "saved",
      text: "You saved Emma's profile",
      time: "2 hours ago",
      icon: Heart,
    },
    {
      id: 2,
      type: "application",
      text: "Application for Marcus moved to 'Home Study' stage",
      time: "1 day ago",
      icon: FileText,
    },
    {
      id: 3,
      type: "resource",
      text: "You completed 'Preparing Your Home' guide",
      time: "2 days ago",
      icon: BookOpen,
    },
  ];

  return (
    <div className="container mx-auto px-4 py-8 pb-24 md:pb-8">
      {/* Welcome Section */}
      <div className="mb-8">
        <h1 className="text-3xl mb-2">Welcome Back!</h1>
        <p className="text-gray-600">
          Continue your journey to building a loving family
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid md:grid-cols-3 gap-6 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-2xl p-6 shadow-sm">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 mb-1">{stat.label}</p>
                  <p className="text-3xl">{stat.value}</p>
                </div>
                <div className={`${stat.bg} ${stat.color} size-14 rounded-full flex items-center justify-center`}>
                  <Icon className="size-7" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl p-8 text-white mb-8">
        <h2 className="text-2xl mb-4">Ready to take the next step?</h2>
        <p className="mb-6 text-orange-50">
          Explore children profiles and find your perfect match
        </p>
        <div className="flex flex-wrap gap-4">
          <Link
            to="/search"
            className="px-6 py-3 bg-white text-orange-600 rounded-lg hover:bg-orange-50 transition-colors"
          >
            Browse Children
          </Link>
          <Link
            to="/resources"
            className="px-6 py-3 bg-orange-700 text-white rounded-lg hover:bg-orange-800 transition-colors"
          >
            View Resources
          </Link>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Current Applications */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl">Current Applications</h2>
            <Link to="/applications" className="text-orange-600 hover:text-orange-700 text-sm">
              View All
            </Link>
          </div>
          <div className="space-y-4">
            <div className="flex items-start gap-4 p-4 bg-blue-50 rounded-lg">
              <div className="size-16 rounded-lg overflow-hidden flex-shrink-0">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1669787210553-44e4f95106ad?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMGJveSUyMHBvcnRyYWl0fGVufDF8fHx8MTc3MDI3NzA5OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Marcus"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1">
                <h3 className="mb-1">Marcus, 10</h3>
                <div className="flex items-center gap-2 text-sm text-blue-700">
                  <Clock className="size-4" />
                  <span>Home Study in Progress</span>
                </div>
              </div>
            </div>
            <Link
              to="/applications"
              className="block text-center py-3 text-orange-600 hover:text-orange-700 transition-colors"
            >
              Start New Application
            </Link>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <h2 className="text-xl mb-6">Recent Activity</h2>
          <div className="space-y-4">
            {recentActivity.map((activity) => {
              const Icon = activity.icon;
              return (
                <div key={activity.id} className="flex items-start gap-3 pb-4 border-b border-gray-100 last:border-0">
                  <div className="size-10 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
                    <Icon className="size-5 text-gray-600" />
                  </div>
                  <div className="flex-1">
                    <p className="text-gray-900 mb-1">{activity.text}</p>
                    <p className="text-sm text-gray-500">{activity.time}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Next Steps */}
      <div className="mt-8 bg-white rounded-2xl p-6 shadow-sm">
        <h2 className="text-xl mb-4">Recommended Next Steps</h2>
        <div className="grid md:grid-cols-3 gap-4">
          <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
            <CheckCircle2 className="size-5 text-green-600 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="mb-1">Complete Your Profile</h3>
              <p className="text-sm text-gray-600">Add more details to help us match you better</p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
            <AlertCircle className="size-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="mb-1">Schedule Counseling</h3>
              <p className="text-sm text-gray-600">Connect with an adoption counselor</p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
            <BookOpen className="size-5 text-purple-600 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="mb-1">Review Resources</h3>
              <p className="text-sm text-gray-600">Learn about the adoption process</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
