import { useState } from "react";
import { useNavigate } from "react-router";
import { Heart, CheckCircle2, ArrowRight, ArrowLeft } from "lucide-react";
import { ImageWithFallback } from "../figma/ImageWithFallback";

export function OnboardingSteps() {
  const [currentStep, setCurrentStep] = useState(0);
  const navigate = useNavigate();

  const steps = [
    {
      title: "Understanding Adoption",
      description: "Learn about the adoption process and what to expect",
      image: "https://images.unsplash.com/photo-1768125806530-ac1b8b279b31?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlsZCUyMHNtaWxpbmclMjBob3BlfGVufDF8fHx8MTc3MDI3NzAxM3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      points: [
        "Review eligibility requirements",
        "Understand timeline expectations",
        "Learn about home study process",
        "Financial considerations",
      ],
    },
    {
      title: "Your Preferences",
      description: "Help us understand what you're looking for",
      image: "https://images.unsplash.com/photo-1597698110516-023a0489ac0c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMGZhbWlseSUyMGRpdmVyc2UlMjBwYXJlbnRzfGVufDF8fHx8MTc3MDI3NzAxMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      points: [
        "Age range preferences",
        "Special needs considerations",
        "Sibling groups",
        "Open vs. closed adoption",
      ],
    },
    {
      title: "Getting Started",
      description: "Next steps on your adoption journey",
      image: "https://images.unsplash.com/photo-1764555241048-f1fc72201704?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXBwb3J0aXZlJTIwY29tbXVuaXR5JTIwaGFuZHN8ZW58MXx8fHwxNzcwMjc3MDEzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      points: [
        "Create your profile",
        "Complete required documentation",
        "Connect with a counselor",
        "Start browsing children profiles",
      ],
    },
  ];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      navigate("/profile");
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    } else {
      navigate("/");
    }
  };

  const step = steps[currentStep];

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-white">
      <div className="container mx-auto px-4 py-12">
        <div className="flex items-center gap-2 mb-8">
          <Heart className="size-8 text-orange-500 fill-orange-500" />
          <span className="text-2xl">FamilyBridge</span>
        </div>

        {/* Progress Bar */}
        <div className="max-w-3xl mx-auto mb-12">
          <div className="flex items-center justify-between mb-2">
            {steps.map((_, index) => (
              <div key={index} className="flex items-center flex-1">
                <div
                  className={`size-10 rounded-full flex items-center justify-center ${
                    index <= currentStep
                      ? "bg-orange-500 text-white"
                      : "bg-gray-200 text-gray-400"
                  }`}
                >
                  {index < currentStep ? (
                    <CheckCircle2 className="size-6" />
                  ) : (
                    <span>{index + 1}</span>
                  )}
                </div>
                {index < steps.length - 1 && (
                  <div
                    className={`h-1 flex-1 mx-2 ${
                      index < currentStep ? "bg-orange-500" : "bg-gray-200"
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between text-sm text-gray-600">
            <span>Step {currentStep + 1} of {steps.length}</span>
          </div>
        </div>

        {/* Content */}
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-3xl shadow-xl overflow-hidden">
            <div className="grid md:grid-cols-2">
              <div className="p-12">
                <h2 className="text-3xl mb-4 text-gray-900">{step.title}</h2>
                <p className="text-xl text-gray-600 mb-8">{step.description}</p>
                <ul className="space-y-4">
                  {step.points.map((point, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <CheckCircle2 className="size-6 text-green-500 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-700">{point}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="relative h-[500px]">
                <ImageWithFallback
                  src={step.image}
                  alt={step.title}
                  className="absolute inset-0 w-full h-full object-cover"
                />
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex justify-between items-center mt-8">
            <button
              onClick={handleBack}
              className="flex items-center gap-2 px-6 py-3 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="size-5" />
              Back
            </button>
            <button
              onClick={handleNext}
              className="flex items-center gap-2 px-8 py-3 bg-orange-500 text-white rounded-full hover:bg-orange-600 transition-colors shadow-lg"
            >
              {currentStep < steps.length - 1 ? "Next" : "Get Started"}
              <ArrowRight className="size-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
