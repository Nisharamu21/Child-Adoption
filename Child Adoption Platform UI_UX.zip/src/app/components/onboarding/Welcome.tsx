import { Link } from "react-router";
import { Heart, Users, BookOpen, Shield } from "lucide-react";
import { ImageWithFallback } from "../figma/ImageWithFallback";

export function Welcome() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-white">
      {/* Hero Section */}
      <div className="container mx-auto px-4 py-12">
        <nav className="flex justify-between items-center mb-16">
          <div className="flex items-center gap-2">
            <Heart className="size-8 text-orange-500 fill-orange-500" />
            <span className="text-2xl">FamilyBridge</span>
          </div>
          <Link
            to="/dashboard"
            className="px-6 py-2 text-orange-600 hover:text-orange-700 transition-colors"
          >
            Sign In
          </Link>
        </nav>

        <div className="grid md:grid-cols-2 gap-12 items-center mb-24">
          <div>
            <h1 className="text-5xl mb-6 text-gray-900">
              Every child deserves a loving home
            </h1>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              Start your journey to parenthood with compassionate guidance every step of the way.
            </p>
            <Link
              to="/onboarding"
              className="inline-block px-8 py-4 bg-orange-500 text-white rounded-full hover:bg-orange-600 transition-colors shadow-lg"
            >
              Begin Your Journey
            </Link>
          </div>
          <div className="rounded-3xl overflow-hidden shadow-2xl">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1597698110516-023a0489ac0c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMGZhbWlseSUyMGRpdmVyc2UlMjBwYXJlbnRzfGVufDF8fHx8MTc3MDI3NzAxMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Happy family"
              className="w-full h-[500px] object-cover"
            />
          </div>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-4 gap-8 mb-24">
          <div className="text-center p-6">
            <div className="inline-flex items-center justify-center size-16 bg-orange-100 rounded-full mb-4">
              <Shield className="size-8 text-orange-600" />
            </div>
            <h3 className="text-xl mb-2">Verified & Safe</h3>
            <p className="text-gray-600">
              All profiles are thoroughly verified for your peace of mind
            </p>
          </div>
          <div className="text-center p-6">
            <div className="inline-flex items-center justify-center size-16 bg-blue-100 rounded-full mb-4">
              <Users className="size-8 text-blue-600" />
            </div>
            <h3 className="text-xl mb-2">Expert Support</h3>
            <p className="text-gray-600">
              Connect with experienced adoption counselors
            </p>
          </div>
          <div className="text-center p-6">
            <div className="inline-flex items-center justify-center size-16 bg-green-100 rounded-full mb-4">
              <BookOpen className="size-8 text-green-600" />
            </div>
            <h3 className="text-xl mb-2">Resources</h3>
            <p className="text-gray-600">
              Access guides and materials for every stage
            </p>
          </div>
          <div className="text-center p-6">
            <div className="inline-flex items-center justify-center size-16 bg-purple-100 rounded-full mb-4">
              <Heart className="size-8 text-purple-600" />
            </div>
            <h3 className="text-xl mb-2">Compassionate</h3>
            <p className="text-gray-600">
              A journey supported by care and understanding
            </p>
          </div>
        </div>

        {/* Testimonial */}
        <div className="bg-white rounded-3xl p-12 shadow-lg max-w-4xl mx-auto text-center">
          <p className="text-2xl text-gray-700 mb-6 italic">
            "FamilyBridge made our adoption journey feel supported and less overwhelming. We found our perfect match and couldn't be happier."
          </p>
          <p className="text-gray-600">— Sarah & Michael, Parents since 2024</p>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-50 border-t border-gray-200 py-8 mt-24">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>© 2026 FamilyBridge. Supporting families with love and care.</p>
        </div>
      </footer>
    </div>
  );
}
