
  # Child Adoption Platform UI/UX

  This is a code bundle for Child Adoption Platform UI/UX. The original project is available at https://www.figma.com/design/MAWOMzbmIyDlM2qJz2o2C6/Child-Adoption-Platform-UI-UX.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  